//Accessing a Global Variable
/*#include <iostream>
using namespace std;

int x = 10;   // Global variable

int main()
{
    int x = 20;   // Local variable

    cout << x << endl;    // Local x
    cout << ::x << endl;  // Global x

    return 0;
}
*/
/*Defining a Member Function Outside the Class
#include <iostream>
using namespace std;

class Student
{
public:
    void display();
};

void Student::display()
{
    cout << "Student Details";
}

int main()
{
    Student s;
    s.display();

    return 0;
}
*/
/*3. Accessing a Static Data Member
#include <iostream>
using namespace std;

class Student
{
public:
    static int count;
};

int Student::count = 10;

int main()
{
    cout << Student::count;
    return 0;
} */
/*4. Accessing Members of a Namespace

#include <iostream>
using namespace std;

namespace A
{
    int x = 100;
}

int main()
{
    cout << A::x;
    return 0;
}*/

//Accessing a Static Member Function

#include <iostream>
using namespace std;

class Student
{
public:
    static void display()
    {
        cout << "Static Member Function";
    }
};

int main()
{
    Student::display();

    return 0;
}

