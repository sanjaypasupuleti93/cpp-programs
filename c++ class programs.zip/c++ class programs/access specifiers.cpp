// default arguments & access specifiers
#include<iostream> 
using namespace std;
class student 
{
	private:
		    int marks;
	public:
	    void setmarks(int m=90)
		{
			marks=m;	
		}   
		void display()
		{
			cout<<"marks are :"<<marks<<endl;
			
	    } 	    
};
main()
{
	student s1,s2;
	s1.setmarks();
	cout<<"students 1:";
	s1.display();
	s2.setmarks(95);
	cout<<"students 2:";
	s2.display();
}


	

