/*
A member function and a friend function are both used to access and manipulate class data in C++, but they differ in how they are defined and how they access class members.

Member Function	                                             Friend Function
Defined inside the class.	                                Declared inside the class using the friend keyword but defined outside the class.
Called using an object (obj.function()).        	          Called like a normal function (function(obj)).
Has direct access to all members of its own class.	            Can access private and protected members, but is not a member of the class.
Uses the this pointer.	                                    Does not use the this pointer.
Can be inherited by derived classes.                     	Cannot be inherited because it is not a class member.*/


//member function & friend function
/*#inclue<iostream>
using namespace std;

class Demo {
private:
    int x;

public:
    void setData(int a) {
        x = a;
    }

    void display() {
        cout << "Value: " << x;
    }
};

int main() {
    Demo d;
    d.setData(10);
    d.display();
    return 0;
}
*/

//frd function
#include <iostream>
using namespace std;

class Demo {
private:
    int x;

public:
    Demo() {
        x = 20;
    }

    friend void display(Demo);
};

void display(Demo d) {
    cout << "Value: " << d.x;
}

int main() {
    Demo d;
    display(d);
    return 0;
}
