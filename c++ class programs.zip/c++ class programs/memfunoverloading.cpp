//Write a short C++ program to demonstrate overloading of a member function named display().
/*
Function overloading means defining multiple functions with the same name but different parameter lists.
Explanation

Here, display() is overloaded because two member functions have the same name but different parameters:

display() ? takes no arguments
display(int n) ? takes one integer argument

The compiler decides which display() function to call based on the arguments passed.*/
#include <iostream>
using namespace std;

class Demo
{
public:
    // display() with no arguments
    void display()
    {
        cout << "Display with no arguments" << endl;
    }

    // display() with one argument
    void display(int n)
    {
        cout << "Display with integer: " << n << endl;
    }
};

int main()
{
    Demo d;

    d.display();
    d.display(10);

    return 0;
}
