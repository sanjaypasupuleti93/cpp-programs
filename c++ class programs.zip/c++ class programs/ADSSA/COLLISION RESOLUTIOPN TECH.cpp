//COLLISION RESOLUTION TECHNIQUE
#include<stdio.h>
#include<stdlib.h>
#define SIZE 10
int HashTable[SIZE];
int size=SIZE;
void init()
{
	for(int i=0;i<size;i++)
	{
		hashTable[i]=-1;
	}
}
void display()
{
	printf("\nHash table: \n");
	for(int i=0;i<size;i++)
	{
		printf("[%d]->%d\n",i,hashTable[i]);
	}
}
/*LINEAR PROBING*/
void linearInsert(int key){
	int index=key% size;
	int start=index;
	while(hashTable[index]!=-1)
	{
		index=(index+1)%size;
		if(index==start)
		{
			printf("Hash table is full:\n");
			return;	
		}
	}

	hashTable[index]=key;
}
/*QUADRATIC PROBING*/
void qudraticInsert(int key)
{
	int index;
		int start=key%size;
		for(int i=0;i<size;i++)
		{
			index=(start+i*i)%size;
			//calculate the next position using i*i
			if(hashtable[index]==-1)
			{
				//If the position is empty,insert the key
				hashTable[index]=key;
				return;
			}
		}
		printf("No empty position found\n");
}	

/*SECOND HASH FUNCTION*/
int hash2(int key){
	return 7-(key%7);
}
/*Double Hashing*/
void doubleHashInsert(int key){
	int h1=key%size;
	int h2=hash2(key);
	int index;
	for(int i=0;i<size;i++)
	{
		index=(h1+i*h2)%size;
		if(hashTable[index]==-1)
		{
			hashTable[index]=key;
			return;
		}
	}
	printf("No empty position found");
}
int main()
{
	
}
