/*1. Definition

An inline function is a function in C++ in which the compiler attempts to replace the function call with the actual function code.
 This can reduce the function-call overhead and improve performance for small functions.

An inline function is declared using the inline keyword.

2. Syntax
inline return_type function_name(parameters)
{
    // function body
}
3. Rules for Inline Functions
The function should be small and simple. 
Inline functions are mainly suitable for functions containing a few statements.
A function can be explicitly declared using the inline keyword.
 A member function defined inside a class is implicitly inline.
4. Example Program  */
#include <iostream>
using namespace std;


class Calculator
{
public:
    // Inline member function
    inline int square(int n)
    {
        return n * n;
    }


    // Member function defined inside class is also implicitly inline
    int cube(int n)
    {
        return n * n * n;
    }
};


int main()
{
    Calculator c;


    cout << "Square of 10 = " << c.square(10) << endl;
    cout << "Cube of 5 = " << c.cube(5) << endl;

     return 0;
}
/*5. Output
Square of 5 = 25
Cube of 3 = 27
6. Advantages
Reduces function-call overhead.
Can improve execution speed for small functions.
Makes small functions more efficient.
7. Important Note

inline is a request to the compiler, not a command. The compiler may decide not to inline a function 
if it considers inlining unsuitable. */
