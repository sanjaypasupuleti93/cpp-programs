#include<iostream>
using namespace std;
int main()
{
	cout<<"hello sanjay";
	return 0;
}
