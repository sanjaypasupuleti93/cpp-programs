#include <iostream>
#include <string>
#include <fstream>

using namespace std;


// ======================================================
// QUESTION CLASS
// ======================================================

class Question
{
private:
    string question;
    string options[4];
    int correctAnswer;

public:

    // Constructor
    Question(string q, string op1, string op2,
             string op3, string op4, int answer)
    {
        question = q;

        options[0] = op1;
        options[1] = op2;
        options[2] = op3;
        options[3] = op4;

        correctAnswer = answer;
    }

    // Display Question
    void displayQuestion(int number)
    {
        cout << "\nQuestion " << number << ":" << endl;
        cout << question << endl << endl;

        cout << "1. " << options[0] << endl;
        cout << "2. " << options[1] << endl;
        cout << "3. " << options[2] << endl;
        cout << "4. " << options[3] << endl;
    }

    // Check Answer
    bool checkAnswer(int answer)
    {
        return answer == correctAnswer;
    }
};


// ======================================================
// QUIZ CLASS
// ======================================================

class Quiz
{
private:

    // Changed from 3 to 10
    Question questions[10];

    int score;

    // Store answers and results for 10 questions
    int answers[10];
    bool result[10];

public:

    // Constructor
    Quiz()
        : questions{

            Question(
                "What is the capital of India?",
                "Mumbai",
                "New Delhi",
                "Chennai",
                "Hyderabad",
                2
            ),

            Question(
                "Which language is used for this project?",
                "Python",
                "Java",
                "C++",
                "HTML",
                3
            ),

            Question(
                "Which concept is a feature of OOP?",
                "Encapsulation",
                "Compilation",
                "Debugging",
                "Linking",
                1
            ),

            Question(
                "Which keyword is used to create a class in C++?",
                "class",
                "object",
                "create",
                "define",
                1
            ),

            Question(
                "Which symbol is used to end a statement in C++?",
                ".",
                ",",
                ";",
                ":",
                3
            ),

            Question(
                "Which function is automatically called when an object is created?",
                "Destructor",
                "Constructor",
                "Main",
                "Display",
                2
            ),

            Question(
                "Which loop is commonly used when the number of iterations is known?",
                "while",
                "do-while",
                "for",
                "switch",
                3
            ),

            Question(
                "Which OOP concept allows one class to acquire properties of another?",
                "Encapsulation",
                "Inheritance",
                "Abstraction",
                "Constructor",
                2
            ),

            Question(
                "Which header file is used for input and output in C++?",
                "iostream",
                "fstream",
                "string",
                "stdio",
                1
            ),

            Question(
                "What is an object?",
                "A function",
                "An instance of a class",
                "A loop",
                "A data type",
                2
            )

        }
    {
        score = 0;
    }


    // ==================================================
    // START QUIZ
    // ==================================================

    void startQuiz(string name)
    {
        score = 0;

        cout << "\n====================================";
        cout << "\n        QUIZ GAME SYSTEM";
        cout << "\n====================================";

        cout << "\n\nEnter User Name: " << name << endl;


        // Display all 10 questions
        for (int i = 0; i < 10; i++)
        {
            questions[i].displayQuestion(i + 1);

            cout << "\nEnter your answer: ";
            cin >> answers[i];


            // Validate answer
            while (answers[i] < 1 || answers[i] > 4)
            {
                cout << "Invalid answer!";
                cout << "\nEnter your answer (1-4): ";
                cin >> answers[i];
            }


            // Check answer
            if (questions[i].checkAnswer(answers[i]))
            {
                result[i] = true;

                // Increase score by 1
                score++;
            }
            else
            {
                result[i] = false;
            }
        }


        // Display final result
        displayResult(name);

        // Save result
        saveResult(name);
    }


    // ==================================================
    // DISPLAY RESULT
    // ==================================================

    void displayResult(string name)
    {
        cout << "\n\n====================================";
        cout << "\n          QUIZ RESULT";
        cout << "\n====================================";


        // Display each answer
        for (int i = 0; i < 10; i++)
        {
            cout << "\nAnswer " << i + 1 << ": ";

            if (result[i])
            {
                cout << "Correct";
            }
            else
            {
                cout << "Wrong";
            }
        }


        // Calculate wrong answers
        int wrongAnswers = 10 - score;


        // Calculate percentage
        double percentage = (score / 10.0) * 100;


        cout << "\n\n------------------------------------";
        cout << "\n          FINAL RESULT";
        cout << "\n------------------------------------";

        cout << "\n\nPlayer Name     : " << name;

        cout << "\nTotal Questions : 10";

        cout << "\nCorrect Answers : " << score;

        cout << "\nWrong Answers   : " << wrongAnswers;

        cout << "\nFinal Score     : "
             << score << " / 10";

        cout << "\nPercentage      : "
             << percentage << "%";


        // Pass / Fail
        if (percentage >= 40)
        {
            cout << "\nResult          : PASS";
        }
        else
        {
            cout << "\nResult          : FAIL";
        }


        if (score == 10)
        {
            cout << "\n\nCongratulations!";
            cout << "\nYou answered all questions correctly!";
        }
        else
        {
            cout << "\n\nYou have completed the quiz.";
        }
    }


    // ==================================================
    // FILE HANDLING
    // ==================================================

    void saveResult(string name)
    {
        ofstream file("quiz_results.txt", ios::app);

        if (file.is_open())
        {
            int wrongAnswers = 10 - score;

            double percentage = (score / 10.0) * 100;


            file << "Player Name     : "
                 << name << endl;

            file << "Total Questions : 10"
                 << endl;

            file << "Correct Answers : "
                 << score << endl;

            file << "Wrong Answers   : "
                 << wrongAnswers << endl;

            file << "Final Score     : "
                 << score << " / 10" << endl;

            file << "Percentage      : "
                 << percentage << "%" << endl;


            if (percentage >= 40)
            {
                file << "Result          : PASS"
                     << endl;
            }
            else
            {
                file << "Result          : FAIL"
                     << endl;
            }


            file << "------------------------------------"
                 << endl;

            file.close();

            cout << "\n\nResult saved successfully!";
        }
        else
        {
            cout << "\n\nError: Unable to save result.";
        }
    }
};


// ======================================================
// MAIN FUNCTION
// ======================================================

int main()
{
    Quiz quiz;

    int choice;
    string name;
    char playAgain;


    do
    {
        // ==============================================
        // MAIN MENU
        // ==============================================

        cout << "\n\n====================================";
        cout << "\n          QUIZ GAME SYSTEM";
        cout << "\n====================================";

        cout << "\n\n1. Start Quiz";
        cout << "\n2. Exit";

        cout << "\n\nEnter your choice: ";
        cin >> choice;


        switch (choice)
        {
            case 1:

                cout << "\nEnter User Name: ";

                cin.ignore();

                getline(cin, name);


                // Start quiz
                quiz.startQuiz(name);


                // Play again
                cout << "\n\nPlay Again? (Y/N): ";
                cin >> playAgain;


                if (playAgain == 'Y' ||
                    playAgain == 'y')
                {
                    break;
                }
                else
                {
                    cout << "\n\nThank you for playing!";
                    cout << "\n\nEND";

                    return 0;
                }


            case 2:

                cout << "\n\nThank you for using Quiz Game System!";
                cout << "\nEND";

                return 0;


            default:

                cout << "\n\nInvalid choice!";
                cout << "\nPlease select 1 or 2.";
        }

    } while (true);


    return 0;
}
